package dev.lumen.client.modules.visual;

import dev.lumen.client.LumenClient;
import dev.lumen.client.anim.AnimationUtils;
import dev.lumen.client.anim.AnimationUtils.VelocityState;
import dev.lumen.client.core.Module;
import dev.lumen.client.core.Category;
import dev.lumen.client.core.setting.BooleanSetting;
import dev.lumen.client.core.setting.EnumSetting;
import net.minecraft.class_310;
import net.minecraft.class_5498;

/**
 * Freelook with fully decoupled camera rotation. Player rotation is never
 * touched - mouse deltas are redirected to cameraYaw/cameraPitch while the
 * mixin chain keeps the entity's server-synced rotation locked.
 */
public class FreelookModule extends Module {
    public enum Mode { HOLD, TOGGLE }
    public enum Perspective { THIRD_PERSON_BACK, THIRD_PERSON_FRONT }

    private static FreelookModule instance;

    public final EnumSetting<Mode> mode = new EnumSetting<>("Mode", Mode.class, Mode.HOLD);
    public final EnumSetting<Perspective> perspective = new EnumSetting<>("Perspective", Perspective.class, Perspective.THIRD_PERSON_BACK);
    public final BooleanSetting invertHorizontal = new BooleanSetting("Invert Horizontal", false);
    public final BooleanSetting invertVertical = new BooleanSetting("Invert Vertical", false);
    public final BooleanSetting smoothReturn = new BooleanSetting("Smooth Snap-Back", true);

    private float cameraYaw;
    private float cameraPitch;
    private final VelocityState yawVelocity = new VelocityState();
    private final VelocityState pitchVelocity = new VelocityState();

    private boolean active;
    private boolean toggleState;
    private boolean returning;
    private class_5498 previousCameraType = class_5498.field_26664;

    public FreelookModule() {
        super("Freelook", "360 degree camera without rotating the player", Category.VISUALS);
        instance = this;
        addSettings(mode, perspective, invertHorizontal, invertVertical, smoothReturn);
    }

    public static FreelookModule get() {
        return instance;
    }

    public boolean isActive() {
        return active;
    }

    public boolean isReturning() {
        return returning;
    }

    public float getCameraYaw() {
        return cameraYaw;
    }

    public float getCameraPitch() {
        return cameraPitch;
    }

    public void addLookDelta(double yawDelta, double pitchDelta) {
        float sensitivity = 0.22f;
        cameraYaw += (float) yawDelta * sensitivity * (invertHorizontal.get() ? -1.0f : 1.0f);
        cameraPitch += (float) pitchDelta * sensitivity * (invertVertical.get() ? -1.0f : 1.0f);
        cameraYaw = net.minecraft.class_3532.method_15393(cameraYaw);
        cameraPitch = Math.max(-90.0f, Math.min(90.0f, cameraPitch));
    }

    @Override
    public void onClientTick() {
        class_310 mc = class_310.method_1551();
        var keybinds = LumenClient.get().getKeybindManager();
        boolean activate;
        if (mode.get() == Mode.HOLD) {
            activate = keybinds.isFreelookDown();
            while (keybinds.consumeFreelookClick()) {
            }
        } else {
            while (keybinds.consumeFreelookClick()) {
                toggleState = !toggleState;
            }
            activate = toggleState;
        }

        if (activate && !active) {
            start(mc);
        } else if (!activate && active) {
            beginReturn(mc);
        }
    }

    private void start(class_310 mc) {
        active = true;
        returning = false;
        class_5498 current = mc.field_1690.method_31044();
        if (current != class_5498.field_26665 && current != class_5498.field_26666) {
            previousCameraType = current;
        }
        class_5498 target = perspective.get() == Perspective.THIRD_PERSON_FRONT
                ? class_5498.field_26666 : class_5498.field_26665;
        mc.field_1690.method_31043(target);
        cameraYaw = mc.field_1724.method_36454();
        cameraPitch = mc.field_1724.method_36455();
        yawVelocity.velocity = 0.0f;
        pitchVelocity.velocity = 0.0f;
    }

    private void beginReturn(class_310 mc) {
        active = false;
        if (smoothReturn.get() && mc.field_1724 != null) {
            returning = true;
        } else {
            finishReturn(mc);
        }
    }

    private void finishReturn(class_310 mc) {
        returning = false;
        mc.field_1690.method_31043(previousCameraType);
    }

    @Override
    public void onRenderTick() {
        class_310 mc = class_310.method_1551();
        if (returning && mc.field_1724 != null) {
            float delta = 0.06f;
            float targetYaw = mc.field_1724.method_36454();
            float targetPitch = mc.field_1724.method_36455();
            float yawDiff = net.minecraft.class_3532.method_15393(targetYaw - cameraYaw);
            cameraYaw = AnimationUtils.springApproach(cameraYaw, cameraYaw + yawDiff, yawVelocity, delta);
            cameraPitch = AnimationUtils.springApproach(cameraPitch, targetPitch, pitchVelocity, delta);
            if (Math.abs(yawDiff) < 0.15f && Math.abs(cameraPitch - targetPitch) < 0.15f) {
                cameraYaw = targetYaw;
                cameraPitch = targetPitch;
                finishReturn(mc);
            }
        }
    }

    @Override
    public void onDisable() {
        class_310 mc = class_310.method_1551();
        active = false;
        toggleState = false;
        returning = false;
        if (mc.field_1690.method_31044() != previousCameraType && mc.field_1724 != null) {
            mc.field_1690.method_31043(previousCameraType);
        }
    }
}
