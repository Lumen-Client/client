package dev.lumen.client.modules.hud;

import dev.lumen.client.anim.Animation;
import dev.lumen.client.anim.Easing;
import dev.lumen.client.core.HudModule;
import dev.lumen.client.render.RenderUtils;
import dev.lumen.client.render.TextRenderer;
import dev.lumen.client.theme.ColorUtils;
import dev.lumen.client.theme.ThemeManager;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ArmorStatusModule extends HudModule {
    private static final int SLOT_COUNT = 5;
    private static final float ROW_H = 22.0f;
    private static final float CARD_W = 132.0f;

    private final Animation[] durabilityAnims = new Animation[SLOT_COUNT];
    private boolean anyVisible;
    private int visibleRows;

    public ArmorStatusModule() {
        super("Armor Status", "Armor and held item durability with numeric values", 300.0f, 6.0f);
        for (int i = 0; i < durabilityAnims.length; i++) {
            durabilityAnims[i] = new Animation(0.25f, Easing::easeOutCubic);
        }
    }

    private class_1799[] collectItems() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return null;
        return new class_1799[]{
                mc.field_1724.method_6118(class_1304.field_6169),
                mc.field_1724.method_6118(class_1304.field_6174),
                mc.field_1724.method_6118(class_1304.field_6172),
                mc.field_1724.method_6118(class_1304.field_6166),
                mc.field_1724.method_6047()
        };
    }

    @Override
    public float getHudWidth() {
        return CARD_W;
    }

    @Override
    public float getHudHeight() {
        return Math.max(1, visibleRows) * ROW_H;
    }

    @Override
    public boolean isContentEmpty() {
        return !anyVisible;
    }

    @Override
    public void preRender() {
        anyVisible = false;
        visibleRows = 0;
    }

    @Override
    public void renderHud(class_332 graphics, float delta) {
        class_1799[] items = collectItems();
        if (items == null) {
            anyVisible = false;
            return;
        }
        ThemeManager theme = ThemeManager.get();

        float rowY = 0.0f;
        for (int i = 0; i < items.length; i++) {
            class_1799 stack = items[i];
            if (stack == null || stack.method_7960()) {
                durabilityAnims[i].setTarget(false);
                durabilityAnims[i].update();
                continue;
            }
            anyVisible = true;
            visibleRows++;
            durabilityAnims[i].setTarget(true);
            durabilityAnims[i].update();
            float alpha = durabilityAnims[i].getValue();
            float y = rowY;
            rowY += ROW_H;

            int bg = ColorUtils.withAlpha(theme.getCard(), (int) (210 * alpha));
            RenderUtils.roundedRect(graphics, 0.0f, y, CARD_W, ROW_H - 2.0f, 4.0f, bg);

            String name = stack.method_7964().getString();
            if (name.length() > 10) name = name.substring(0, 10);
            TextRenderer.draw(graphics, name, 6.0f, y + 3.5f, ColorUtils.withAlpha(theme.getText(), (int) (255 * alpha)), true);

            int maxDamage = stack.method_7936();
            if (maxDamage > 0) {
                int remaining = maxDamage - stack.method_7919();
                float percent = (float) remaining / maxDamage;
                int barColor = percent > 0.5f ? 0xFF5EFF8A : percent > 0.2f ? 0xFFFFD65E : 0xFFFF5E5E;
                RenderUtils.fill(graphics, 6.0f, y + 15.0f, CARD_W - 12.0f, 3.0f, ColorUtils.withAlpha(0xFF000000, (int) (160 * alpha)));
                RenderUtils.fill(graphics, 6.0f, y + 15.0f, (CARD_W - 12.0f) * percent, 3.0f, ColorUtils.withAlpha(barColor, (int) (255 * alpha)));

                String durability = remaining + "/" + maxDamage;
                float durW = TextRenderer.width(durability);
                TextRenderer.draw(graphics, durability, CARD_W - 6.0f - durW, y + 3.5f,
                        ColorUtils.withAlpha(barColor, (int) (255 * alpha)), true);
            }
        }
    }
}
