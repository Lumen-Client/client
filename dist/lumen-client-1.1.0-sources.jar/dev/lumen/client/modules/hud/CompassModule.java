package dev.lumen.client.modules.hud;

import dev.lumen.client.core.HudModule;
import dev.lumen.client.render.RenderUtils;
import dev.lumen.client.render.TextRenderer;
import dev.lumen.client.theme.ColorUtils;
import dev.lumen.client.theme.ThemeManager;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;

public class CompassModule extends HudModule {
    private static final String[] TICK_LABELS = {"S", "SW", "W", "NW", "N", "NE", "E", "SE"};

    public CompassModule() {
        super("Compass", "Scrolling cardinal direction bar", 160.0f, 6.0f);
    }

    @Override
    public float getHudWidth() {
        return 160.0f;
    }

    @Override
    public float getHudHeight() {
        return TextRenderer.height() + 10.0f;
    }

    @Override
    public void renderHud(class_332 graphics, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        ThemeManager theme = ThemeManager.get();
        float yaw = class_3532.method_15393(mc.field_1724.method_36454());
        float width = getHudWidth();
        float centerX = width / 2.0f;
        float pixelsPerDegree = width / 180.0f;

        RenderUtils.verticalGradient(graphics, 0.0f, 0.0f, width, getHudHeight(),
                ColorUtils.withAlpha(theme.getBackground(), 0), ColorUtils.withAlpha(theme.getBackground(), 160));

        for (int deg = -180; deg <= 180; deg += 45) {
            float diff = class_3532.method_15393(deg - yaw);
            if (Math.abs(diff) > 90.0f) continue;
            float px = centerX + diff * pixelsPerDegree;
            int labelIndex = ((deg + 180) / 45) % 8;
            String label = TICK_LABELS[labelIndex < 0 ? labelIndex + 8 : labelIndex];
            float fade = 1.0f - Math.abs(diff) / 90.0f;
            int color = ColorUtils.withAlpha(theme.getText(), (int) (140 + 115 * fade));
            TextRenderer.draw(graphics, label, px - TextRenderer.width(label) / 2.0f, 4.0f, color, true);
        }

        RenderUtils.fill(graphics, centerX - 1.0f, 2.0f, 2.0f, getHudHeight() - 4.0f, theme.gradientColor(0.5f));
    }
}
