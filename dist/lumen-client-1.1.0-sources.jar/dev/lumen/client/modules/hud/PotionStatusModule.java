package dev.lumen.client.modules.hud;

import dev.lumen.client.anim.Animation;
import dev.lumen.client.anim.Easing;
import dev.lumen.client.core.HudModule;
import dev.lumen.client.render.RenderUtils;
import dev.lumen.client.render.TextRenderer;
import dev.lumen.client.theme.ColorUtils;
import dev.lumen.client.theme.ThemeManager;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_6880;

public class PotionStatusModule extends HudModule {
    private static final class Row {
        final Animation anim = new Animation(0.2f, Easing::easeOutCubic);
        String label = "";
        int color;
        boolean active;
    }

    private final List<Row> rows = new ArrayList<>();
    private int lastRowCount;
    private boolean anyVisible;

    public PotionStatusModule() {
        super("Potion Status", "Active effect timers", 150.0f, 6.0f);
    }

    @Override
    public float getHudWidth() {
        return 130.0f;
    }

    @Override
    public float getHudHeight() {
        int count = 0;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            count = Math.min(mc.field_1724.method_6026().size(), 8);
        }
        return Math.max(count, 1) * 22.0f;
    }

    @Override
    public boolean isContentEmpty() {
        return !anyVisible;
    }

    @Override
    public void preRender() {
        anyVisible = false;
    }

    @Override
    public void renderHud(class_332 graphics, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) {
            anyVisible = false;
            return;
        }
        ThemeManager theme = ThemeManager.get();

        Collection<class_1293> effects = mc.field_1724.method_6026();
        int index = 0;
        for (class_1293 instance : effects) {
            if (index >= rows.size()) rows.add(new Row());
            Row row = rows.get(index);
            class_6880<class_1291> effect = instance.method_5579();
            String name = effect.comp_349().method_5560().getString();
            int amp = instance.method_5578();
            String label = name + (amp > 0 ? " " + (amp + 1) : "") + " " + (instance.method_5584() / 20) + "s";
            row.label = label;
            row.color = effect.comp_349().method_5556();
            row.anim.setTarget(true);
            row.anim.update();
            renderRow(graphics, row, index * 22.0f, theme);
            index++;
            if (index >= 8) break;
        }
        for (int i = index; i < rows.size() && i < lastRowCount; i++) {
            Row row = rows.get(i);
            row.anim.setTarget(false);
            row.anim.update();
            if (row.anim.getValue() > 0.02f) {
                renderRow(graphics, row, i * 22.0f, theme);
                anyVisible = true;
            }
        }
        anyVisible = anyVisible || index > 0;
        lastRowCount = index;
    }

    private void renderRow(class_332 graphics, Row row, float y, ThemeManager theme) {
        float alpha = row.anim.getValue();
        int bg = ColorUtils.withAlpha(theme.getCard(), (int) (210 * alpha));
        RenderUtils.roundedRect(graphics, 0.0f, y, 130.0f, 20.0f, 4.0f, bg);
        RenderUtils.fill(graphics, 0.0f, y, 2.5f, 20.0f, ColorUtils.withAlpha(row.color, (int) (255 * alpha)));
        TextRenderer.draw(graphics, row.label, 7.0f, y + 5.0f, ColorUtils.withAlpha(theme.getText(), (int) (255 * alpha)), true);
    }
}
