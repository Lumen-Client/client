package dev.lumen.client.modules.hud;

import dev.lumen.client.anim.Animation;
import dev.lumen.client.anim.Easing;
import dev.lumen.client.core.HudModule;
import dev.lumen.client.render.TextRenderer;
import dev.lumen.client.theme.ColorUtils;
import dev.lumen.client.theme.ThemeManager;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ComboCounterModule extends HudModule {
    private final Animation popAnim = new Animation(0.35f, Easing::spring);
    private int combo;
    private long lastHitMillis;
    private String displayText = "";
    private boolean mouseWasDown;

    public ComboCounterModule() {
        super("Combo Counter", "Consecutive hits landed", 250.0f, 130.0f);
    }

    @Override
    public void onClientTick() {
        if (class_310.method_1551().field_1724 == null) {
            combo = 0;
            displayText = "";
            mouseWasDown = false;
            return;
        }
        if (combo > 0 && System.currentTimeMillis() - lastHitMillis > 2500) {
            combo = 0;
            displayText = "";
        }
    }

    /**
     * Runs once per frame from renderHud: registers a hit only on the
     * left-click press edge while the crosshair is on a living entity and
     * the attack cooldown is recharged, so holding the button no longer
     * spams the counter every tick.
     */
    private void detectAttack(class_310 mc) {
        boolean down = mc.field_1729.method_1608();
        if (down && !mouseWasDown) {
            boolean charged = mc.field_1724.method_7261(0.0f) > 0.95f;
            class_1297 target = mc.field_1692;
            if (charged && target instanceof class_1309 && target != mc.field_1724) {
                registerHit();
            }
        }
        mouseWasDown = down;
    }

    public void registerHit() {
        combo++;
        lastHitMillis = System.currentTimeMillis();
        displayText = combo + " Combo";
        popAnim.snap(false);
        popAnim.setTarget(true);
    }

    @Override
    public float getHudWidth() {
        return Math.max(TextRenderer.width(displayText) + 10.0f, 50.0f);
    }

    @Override
    public float getHudHeight() {
        return TextRenderer.height() + 8.0f;
    }

    @Override
    public boolean isContentEmpty() {
        return displayText.isEmpty();
    }

    @Override
    public void preRender() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null) {
            detectAttack(mc);
        }
        popAnim.update();
    }

    @Override
    public void renderHud(class_332 graphics, float delta) {
        if (displayText.isEmpty()) return;
        float pop = 1.0f + 0.25f * (1.0f - popAnim.getValue());
        ThemeManager theme = ThemeManager.get();
        TextRenderer.drawScaled(graphics, displayText, 5.0f, 4.0f + (pop - 1.0f) * 4.0f,
                ColorUtils.withAlpha(theme.getPrimary(), 255), pop, true);
    }
}
