package dev.lumen.client.modules.hud;

import dev.lumen.client.core.HudModule;
import dev.lumen.client.render.TextRenderer;
import dev.lumen.client.theme.ColorUtils;
import dev.lumen.client.theme.ThemeManager;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_2338;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_5321;
import net.minecraft.class_6880;

public class CoordinatesModule extends HudModule {
    private final dev.lumen.client.core.setting.BooleanSetting showBiome =
            new dev.lumen.client.core.setting.BooleanSetting("Show Biome", true);
    private final dev.lumen.client.core.setting.BooleanSetting netherConverter =
            new dev.lumen.client.core.setting.BooleanSetting("Nether Converter", true);

    public CoordinatesModule() {
        super("Coordinates", "XYZ, dimension converter and biome", 6.0f, 84.0f);
        addSettings(showBiome, netherConverter);
    }

    @Override
    public float getHudWidth() {
        return 150.0f;
    }

    @Override
    public float getHudHeight() {
        class_310 mc = class_310.method_1551();
        int lines = 1;
        if (netherConverter.get()) lines++;
        if (showBiome.get() && mc.field_1687 != null) lines++;
        return lines * (TextRenderer.height() + 3.0f) + 6.0f;
    }

    @Override
    public void renderHud(class_332 graphics, float delta) {
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        ThemeManager theme = ThemeManager.get();
        int text = theme.getText();
        int accent = theme.getPrimary();

        double x = mc.field_1724.method_23317();
        double y = mc.field_1724.method_23318();
        double z = mc.field_1724.method_23321();
        float lineH = TextRenderer.height() + 3.0f;
        float cy = 3.0f;

        TextRenderer.draw(graphics, String.format("XYZ %.0f %.0f %.0f", x, y, z), 5.0f, cy, ColorUtils.withAlpha(text, 255), true);
        cy += lineH;

        if (netherConverter.get()) {
            class_5321<class_1937> dimension = mc.field_1687.method_27983();
            if (dimension == class_1937.field_25180) {
                TextRenderer.draw(graphics, String.format("Overworld %.0f %.0f", x * 8.0, z * 8.0), 5.0f, cy, ColorUtils.withAlpha(accent, 230), true);
            } else if (dimension == class_1937.field_25179) {
                TextRenderer.draw(graphics, String.format("Nether %.0f %.0f", x / 8.0, z / 8.0), 5.0f, cy, ColorUtils.withAlpha(accent, 230), true);
            } else {
                TextRenderer.draw(graphics, "No conversion", 5.0f, cy, ColorUtils.withAlpha(text, 140), true);
            }
            cy += lineH;
        }

        if (showBiome.get() && mc.field_1687 != null) {
            class_2338 pos = mc.field_1724.method_24515();
            class_6880<class_1959> biome = mc.field_1687.method_23753(pos);
            String biomeName = biome.method_40230().map(k -> k.method_29177().method_12832()).orElse("unknown");
            TextRenderer.draw(graphics, "Biome " + biomeName, 5.0f, cy, ColorUtils.withAlpha(text, 210), true);
        }
    }
}
