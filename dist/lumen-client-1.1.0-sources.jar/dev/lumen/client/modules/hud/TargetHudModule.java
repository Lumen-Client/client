package dev.lumen.client.modules.hud;

import dev.lumen.client.anim.Animation;
import dev.lumen.client.anim.AnimationUtils;
import dev.lumen.client.anim.Easing;
import dev.lumen.client.core.HudModule;
import dev.lumen.client.render.RenderUtils;
import dev.lumen.client.render.TextRenderer;
import dev.lumen.client.theme.ColorUtils;
import dev.lumen.client.theme.ThemeManager;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class TargetHudModule extends HudModule {
    private static final class_2960 HEART_FULL = class_2960.method_60656("hud/heart/full");
    private static final class_2960 HEART_HALF = class_2960.method_60656("hud/heart/half");
    private static final class_2960 HEART_CONTAINER = class_2960.method_60656("hud/heart/container");
    private static final float HEART_SIZE = 9.0f;
    private static final float HEART_STEP = 10.0f;
    private static final int HEART_COUNT = 10;

    private final Animation showAnim = new Animation(0.2f, Easing::easeOutCubic);
    private final Animation healthAnim = new Animation(0.25f, Easing::easeOutCubic);
    private String targetName = "";
    private float targetHealthPercent;

    public TargetHudModule() {
        super("Target HUD", "Health bar and hearts of the entity you are looking at", 170.0f, 90.0f);
    }

    @Override
    public void onClientTick() {
        class_310 mc = class_310.method_1551();
        class_1297 target = mc.field_1692;
        boolean valid = target instanceof class_1309 living && living.method_5805() && living != mc.field_1724;
        showAnim.setTarget(valid);
        if (valid) {
            class_1309 living = (class_1309) target;
            targetName = living.method_5477().getString();
            targetHealthPercent = living.method_6032() / Math.max(1.0f, living.method_6063());
            healthAnim.setTarget(true);
        }
    }

    @Override
    public float getHudWidth() {
        return 130.0f;
    }

    @Override
    public float getHudHeight() {
        return 46.0f;
    }

    @Override
    public boolean isContentEmpty() {
        return showAnim.getValue() < 0.02f;
    }

    @Override
    public void preRender() {
        showAnim.update();
        healthAnim.update();
    }

    @Override
    public void renderHud(class_332 graphics, float delta) {
        float alpha = showAnim.getValue();
        if (alpha < 0.02f) return;
        ThemeManager theme = ThemeManager.get();

        RenderUtils.roundedRect(graphics, 0.0f, 0.0f, 130.0f, 46.0f, 5.0f, ColorUtils.withAlpha(theme.getCard(), (int) (215 * alpha)));
        TextRenderer.draw(graphics, targetName, 8.0f, 5.0f, ColorUtils.withAlpha(theme.getText(), (int) (255 * alpha)), true);

        float shown = AnimationUtils.lerp(0.0f, targetHealthPercent, healthAnim.getValue());
        RenderUtils.fill(graphics, 8.0f, 17.0f, 114.0f, 5.0f, ColorUtils.withAlpha(0xFF000000, (int) (170 * alpha)));
        RenderUtils.fill(graphics, 8.0f, 17.0f, Math.max(3.0f, 114.0f * shown), 5.0f,
                ColorUtils.withAlpha(theme.getPrimary(), (int) (255 * alpha)));

        float filled = shown * HEART_COUNT;
        for (int i = 0; i < HEART_COUNT; i++) {
            int hx = (int) (8.0f + i * HEART_STEP);
            int hy = 29;
            float fill = Math.max(0.0f, Math.min(1.0f, filled - i));
            class_2960 sprite = fill >= 0.5f ? HEART_FULL : fill > 0.0f ? HEART_HALF : HEART_CONTAINER;
            graphics.method_52706(net.minecraft.class_10799.field_56883, sprite, hx, hy,
                    (int) HEART_SIZE, (int) HEART_SIZE);
        }
    }
}
