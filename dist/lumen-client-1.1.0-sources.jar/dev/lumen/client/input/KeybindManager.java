package dev.lumen.client.input;

import dev.lumen.client.LumenClient;
import dev.lumen.client.core.Module;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/**
 * Registers all Lumen keybinds into Minecraft's native Controls menu under
 * the "Lumen Client" category, and keeps module keybinds in sync.
 */
public class KeybindManager {
    public static final class_304.class_11900 LUMEN_CATEGORY =
            class_304.class_11900.method_74698(class_2960.method_60655("lumen", "lumen"));

    private final class_304 openClickGui = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.lumen.clickgui", class_3675.class_307.field_1668, GLFW.GLFW_KEY_RIGHT_SHIFT, LUMEN_CATEGORY));
    private final class_304 openHudEditor = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.lumen.hud_editor", class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN, LUMEN_CATEGORY));
    private final class_304 zoom = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.lumen.zoom", class_3675.class_307.field_1668, GLFW.GLFW_KEY_C, LUMEN_CATEGORY));
    private final class_304 freelook = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.lumen.freelook", class_3675.class_307.field_1668, GLFW.GLFW_KEY_LEFT_ALT, LUMEN_CATEGORY));
    private final class_304 fullbright = KeyBindingHelper.registerKeyBinding(new class_304(
            "key.lumen.fullbright", class_3675.class_307.field_1668, GLFW.GLFW_KEY_G, LUMEN_CATEGORY));

    private final Map<Integer, Boolean> moduleKeyStates = new HashMap<>();

    public void tick(class_310 minecraft) {
        while (openClickGui.method_1436()) {
            LumenClient.get().openClickGui(minecraft);
        }
        while (openHudEditor.method_1436()) {
            LumenClient.get().openHudEditor(minecraft);
        }
        while (fullbright.method_1436()) {
            Module fullbrightModule = LumenClient.get().getModuleManager().get(dev.lumen.client.modules.visual.FullbrightModule.class);
            if (fullbrightModule != null) {
                fullbrightModule.toggle();
            }
        }

        if (minecraft.field_1755 == null && minecraft.field_1724 != null) {
            for (Module module : LumenClient.get().getModuleManager().getModules()) {
                int key = module.getKeyCode();
                if (key == -1) continue;
                boolean down = class_3675.method_15987(minecraft.method_22683(), key);
                Boolean previous = moduleKeyStates.get(key);
                if (down && !Boolean.TRUE.equals(previous)) {
                    module.handleKeyPress(key);
                }
                moduleKeyStates.put(key, down);
            }
        }
    }

    public boolean isZoomDown() {
        return zoom.method_1434();
    }

    public boolean consumeZoomClick() {
        return zoom.method_1436();
    }

    public boolean isFreelookDown() {
        return freelook.method_1434();
    }

    public boolean consumeFreelookClick() {
        return freelook.method_1436();
    }

    public class_304 getZoomMapping() {
        return zoom;
    }

    public class_304 getFreelookMapping() {
        return freelook;
    }

    public class_304 getFullbrightMapping() {
        return fullbright;
    }

    public class_304 getClickGuiMapping() {
        return openClickGui;
    }

    public class_304 getHudEditorMapping() {
        return openHudEditor;
    }
}
