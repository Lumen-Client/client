package dev.lumen.client.sfx;

import net.minecraft.class_1109;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;

/**
 * Subtle UI sound effects for the client. All sounds are played through the
 * UI sound channel (no positional audio) at low volume so they stay clean
 * and non-intrusive. Every call is a no-op when the sound manager is not
 * ready (e.g. during startup).
 */
public final class ClientSounds {
    private static final float VOLUME = 0.18f;

    private ClientSounds() {
    }

    private static void ui(class_3414 sound, float pitch) {
        class_310 minecraft = class_310.method_1551();
        if (minecraft == null || minecraft.method_1483() == null) return;
        minecraft.method_1483().method_4873(class_1109.method_4757(sound, pitch, VOLUME));
    }

    public static void guiOpen() {
        ui(class_3417.field_14725.comp_349(), 1.6f);
    }

    public static void guiClose() {
        ui(class_3417.field_14725.comp_349(), 1.2f);
    }

    public static void click() {
        ui(class_3417.field_15015.comp_349(), 1.5f);
    }

    public static void toggleOn() {
        ui(class_3417.field_15204.comp_349(), 1.8f);
    }

    public static void toggleOff() {
        ui(class_3417.field_15204.comp_349(), 1.3f);
    }

    public static void sliderTick() {
        ui(class_3417.field_15204.comp_349(), 2.0f);
    }

    public static void moduleEnable() {
        ui(class_3417.field_14627, 1.7f);
    }

    public static void moduleDisable() {
        ui(class_3417.field_14627, 1.1f);
    }

    public static void snap() {
        ui(class_3417.field_18311.comp_349(), 1.9f);
    }
}
