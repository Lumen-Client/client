package dev.lumen.client.mixin;

import dev.lumen.client.render.RenderUtils;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Draws a small subtle Lumen logo in the bottom-left corner of every
 * container screen (inventory, chests, furnaces, crafting tables, ...).
 */
@Mixin(class_465.class)
public class AbstractContainerScreenMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void lumen$containerLogo(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        int size = 10;
        int x = 4;
        int y = graphics.method_51443() - size - 4;
        RenderUtils.drawTexture(graphics, RenderUtils.LOGO_TEXTURE, x, y, size, size, 0x90FFFFFF);
    }
}
