package dev.lumen.client.mixin;

import dev.lumen.client.modules.perf.EntityOptimizerModule;
import net.minecraft.class_11683.class_11792;
import net.minecraft.class_11954;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2586;
import net.minecraft.class_824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Distance culling for block entities (chests, signs, item frames, ...).
 */
@Mixin(class_824.class)
public class BlockEntityRenderDispatcherMixin {
    @Shadow
    private class_243 cameraPos;

    @Inject(method = "tryExtractRenderState", at = @At("HEAD"), cancellable = true)
    private <E extends class_2586, S extends class_11954> void lumen$distanceCull(
            E blockEntity, float partialTick, class_11792 crumblingOverlay,
            CallbackInfoReturnable<S> cir) {
        EntityOptimizerModule module = EntityOptimizerModule.get();
        if (module == null || !module.isEnabled() || cameraPos == null) return;
        class_2338 pos = blockEntity.method_11016();
        double dx = pos.method_10263() + 0.5 - cameraPos.field_1352;
        double dy = pos.method_10264() + 0.5 - cameraPos.field_1351;
        double dz = pos.method_10260() + 0.5 - cameraPos.field_1350;
        if (module.shouldCullBlockEntity(dx * dx + dy * dy + dz * dz)) {
            cir.setReturnValue(null);
        }
    }
}
