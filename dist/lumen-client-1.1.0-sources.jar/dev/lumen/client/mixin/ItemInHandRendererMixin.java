package dev.lumen.client.mixin;

import dev.lumen.client.modules.visual.LowShieldModule;
import net.minecraft.class_11659;
import net.minecraft.class_1819;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_759;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Lowers the first-person shield while blocking. The hand quads are built
 * from this pose stack, so translating it moves the held shield down without
 * affecting the camera or other players.
 */
@Mixin(class_759.class)
public class ItemInHandRendererMixin {

    @Inject(method = "renderHandsWithItems(FLcom/mojang/blaze3d/vertex/PoseStack;Lnet/minecraft/client/renderer/SubmitNodeCollector;Lnet/minecraft/client/player/LocalPlayer;I)V",
            at = @At("HEAD"))
    private void lumen$lowShield(float partialTick, class_4587 poseStack, class_11659 collector,
                                 class_746 player, int light, CallbackInfo ci) {
        LowShieldModule module = LowShieldModule.get();
        if (module == null || !module.isEnabled()) return;
        if (player == null || !player.method_6115()) return;
        if (!(player.method_6030().method_7909() instanceof class_1819)) return;
        poseStack.method_46416(0.0f, -module.getOffset(), 0.0f);
    }
}
