package dev.lumen.client.mixin;

import dev.lumen.client.modules.perf.EntityOptimizerModule;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4604;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Distance culling for entity rendering.
 */
@Mixin(class_898.class)
public class EntityRenderDispatcherMixin {
    @Shadow
    public class_4184 camera;

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends class_1297> void lumen$distanceCull(E entity, class_4604 frustum, double x, double y, double z,
                                                       CallbackInfoReturnable<Boolean> cir) {
        EntityOptimizerModule module = EntityOptimizerModule.get();
        if (module == null || !module.isEnabled() || camera == null) return;
        class_243 pos = camera.method_71156();
        double dx = x - pos.field_1352;
        double dy = y - pos.field_1351;
        double dz = z - pos.field_1350;
        if (module.shouldCullEntity(dx * dx + dy * dy + dz * dz)) {
            cir.setReturnValue(false);
        }
    }
}
