package dev.lumen.client.mixin;

import dev.lumen.client.modules.visual.LowFireModule;
import net.minecraft.class_1058;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4603;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Compresses the first-person fire overlay. In 1.21.11 the fire overlay is
 * drawn by ScreenEffectRenderer.renderFire as two camera-space quads spanning
 * y in [-0.8, 0.2]; scaling the pose towards the quad bottom squashes the
 * flames down to the configured screen fraction.
 */
@Mixin(class_4603.class)
public class ScreenEffectRendererMixin {

    @Inject(method = "renderFire", at = @At("HEAD"))
    private static void lumen$lowFire(class_4587 poseStack, class_4597 bufferSource, class_1058 sprite, CallbackInfo ci) {
        LowFireModule module = LowFireModule.get();
        if (module == null || !module.isEnabled()) return;
        float fraction = Math.max(0.05f, Math.min(1.0f, module.getFireHeightFraction()));
        poseStack.method_46416(0.0f, -0.8f * (1.0f - fraction), 0.0f);
        poseStack.method_22905(1.0f, fraction, 1.0f);
    }
}
