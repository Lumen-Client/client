package dev.lumen.client.mixin;

import dev.lumen.client.modules.visual.FreelookModule;
import net.minecraft.class_1297;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Redirects the local player's Entity#turn into the freelook camera while
 * active, keeping server-synced rotation untouched.
 */
@Mixin(class_1297.class)
public class EntityTurnMixin {

    @Inject(method = "turn(DD)V", at = @At("HEAD"), cancellable = true)
    private void lumen$freelookTurn(double yRot, double xRot, CallbackInfo ci) {
        FreelookModule freelook = FreelookModule.get();
        if (freelook == null || !freelook.isEnabled() || !freelook.isActive()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 != null && (Object) this == mc.field_1724) {
            freelook.addLookDelta(yRot, xRot);
            ci.cancel();
        }
    }
}
