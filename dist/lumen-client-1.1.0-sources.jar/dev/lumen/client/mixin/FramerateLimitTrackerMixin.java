package dev.lumen.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.lumen.client.modules.perf.RenderOptimizerModule;
import net.minecraft.class_310;
import net.minecraft.class_9919;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Unfocused/minimized FPS limiter.
 */
@Mixin(class_9919.class)
public class FramerateLimitTrackerMixin {

    @ModifyReturnValue(method = "getFramerateLimit", at = @At("RETURN"))
    private int lumen$unfocusedLimit(int original) {
        class_310 mc = class_310.method_1551();
        if (mc == null || mc.method_1569()) return original;
        RenderOptimizerModule module = RenderOptimizerModule.get();
        if (module == null) return original;
        return module.getUnfocusedFpsLimit(original);
    }
}
