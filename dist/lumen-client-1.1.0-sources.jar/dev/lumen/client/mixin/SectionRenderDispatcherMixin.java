package dev.lumen.client.mixin;

import dev.lumen.client.modules.perf.ChunkOptimizerModule;
import net.minecraft.class_846;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Frame-budgeted chunk section uploads and compile-queue capping.
 */
@Mixin(class_846.class)
public class SectionRenderDispatcherMixin {
    @Unique
    private long lumen$uploadStartNanos;

    @Inject(method = "uploadAllPendingUploads", at = @At("HEAD"), cancellable = true)
    private void lumen$budgetUploads(CallbackInfo ci) {
        ChunkOptimizerModule module = ChunkOptimizerModule.get();
        if (module == null || module.hasUploadBudget()) {
            lumen$uploadStartNanos = System.nanoTime();
        } else {
            ci.cancel();
        }
    }

    @Inject(method = "uploadAllPendingUploads", at = @At("RETURN"))
    private void lumen$spend(CallbackInfo ci) {
        ChunkOptimizerModule module = ChunkOptimizerModule.get();
        if (module != null && lumen$uploadStartNanos != 0) {
            module.onUploadSpent(System.nanoTime() - lumen$uploadStartNanos);
            lumen$uploadStartNanos = 0;
        }
    }

    @Inject(method = "schedule", at = @At("HEAD"), cancellable = true)
    private void lumen$queueCap(class_846.class_851.class_4577 task, CallbackInfo ci) {
        ChunkOptimizerModule module = ChunkOptimizerModule.get();
        if (module == null || !module.isEnabled()) return;
        if (((class_846) (Object) this).method_72046() >= module.getMaxCompileQueue()) {
            ci.cancel();
        }
    }
}
