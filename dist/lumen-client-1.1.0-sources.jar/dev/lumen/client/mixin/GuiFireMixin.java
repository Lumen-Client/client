package dev.lumen.client.mixin;

import dev.lumen.client.modules.visual.LowFireModule;
import net.minecraft.class_10799;
import net.minecraft.class_2960;
import net.minecraft.class_329;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Compresses the first-person fire overlay to a configurable screen fraction.
 */
@Mixin(class_329.class)
public class GuiFireMixin {

    @Inject(method = "renderTextureOverlay(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/resources/Identifier;F)V",
            at = @At("HEAD"), cancellable = true)
    private void lumen$lowFire(class_332 graphics, class_2960 identifier, float alpha, CallbackInfo ci) {
        LowFireModule module = LowFireModule.get();
        if (module == null || !module.isEnabled()) return;
        if (identifier == null || !identifier.method_12832().contains("fire")) return;

        int height = graphics.method_51443();
        int lowHeight = Math.max(1, (int) (height * module.getFireHeightFraction()));
        graphics.method_25290(class_10799.field_56883, identifier, 0, height - lowHeight,
                0.0f, 0.0f, graphics.method_51421(), lowHeight, 256, 256);
        ci.cancel();
    }
}
