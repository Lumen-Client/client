package dev.lumen.client.mixin;

import dev.lumen.client.render.RenderUtils;
import dev.lumen.client.render.TextRenderer;
import dev.lumen.client.theme.ColorUtils;
import dev.lumen.client.theme.ThemeManager;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_4011;
import net.minecraft.class_425;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;




/**
 * Replaces the vanilla Mojang loading overlay with Lumen's branded loading
 * screen: client logo, rotating spinner, themed progress bar and live status
 * text. All vanilla reload/finish logic (tick, onFinish, fade timing) is
 * kept intact - only the visuals are replaced. On completion the logo
 * smoothly slides off the top of the screen.
 */
@Mixin(class_425.class)
public class LoadingOverlayMixin {
    @Shadow
    @Final
    private class_310 minecraft;

    @Shadow
    @Final
    private class_4011 reload;

    @Shadow
    @Final
    private boolean fadeIn;

    @Shadow
    private float currentProgress;

    @Shadow
    private long fadeOutStart;

    @Shadow
    private long fadeInStart;

    @Shadow
    @Final
    public static long FADE_OUT_TIME;

    @Shadow
    @Final
    public static long FADE_IN_TIME;

    @Shadow
    private boolean isReadyToFadeOut() {
        throw new AssertionError();
    }

    @Inject(method = "render", at = @At("HEAD"), cancellable = true)
    private void lumen$customLoadingScreen(class_332 graphics, int mouseX, int mouseY, float partialTick, CallbackInfo ci) {
        ThemeManager theme = ThemeManager.get();
        long now = class_156.method_658();
        if (fadeIn && fadeInStart == -1L) {
            fadeInStart = now;
        }
        if (fadeOutStart == -1L) {
            currentProgress = class_3532.method_15363(currentProgress * 0.95f + reload.method_18229() * 0.05f, 0.0f, 1.0f);
        }

        float alpha = 1.0f;
        if (fadeIn && fadeInStart != -1L) {
            alpha = class_3532.method_15363((now - fadeInStart) / (float) FADE_IN_TIME, 0.0f, 1.0f);
        }
        float exit = 0.0f;
        if (fadeOutStart != -1L) {
            exit = class_3532.method_15363((now - fadeOutStart) / (float) FADE_OUT_TIME, 0.0f, 1.0f);
            alpha = 1.0f - exit;
        }
        if (alpha < 0.0f) alpha = 0.0f;

        int w = graphics.method_51421();
        int h = graphics.method_51443();
        RenderUtils.fill(graphics, 0, 0, w, h, theme.getBackground());

        float logoSize = Math.min(w, h) * 0.22f;
        float baseY = h * 0.38f;
        float slide = exit * exit * exit * (baseY + logoSize + 20.0f);
        float logoX = w / 2.0f - logoSize / 2.0f;
        float logoY = baseY - logoSize / 2.0f - slide;
        RenderUtils.drawTexture(graphics, RenderUtils.LOGO_TEXTURE, logoX, logoY, logoSize, logoSize,
                ColorUtils.withAlpha(0xFFFFFF, (int) (255 * alpha)));

        float cx = w / 2.0f;
        float spinY = baseY + logoSize * 0.75f + 26.0f;
        drawSpinner(graphics, cx, spinY, 11.0f, now, alpha);

        if (exit <= 0.0f) {
            float barW = Math.min(w * 0.32f, 240.0f);
            float barY = spinY + 26.0f;
            RenderUtils.roundedRect(graphics, cx - barW / 2.0f, barY, barW, 6.0f, 3.0f,
                    ColorUtils.withAlpha(0xFF2A2A33, 255));
            RenderUtils.roundedGradient(graphics, cx - barW / 2.0f, barY,
                    Math.max(6.0f, barW * currentProgress), 6.0f, 3.0f,
                    theme.getPrimary(), theme.getSecondary(), false);

            String status = statusText();
            float statusW = TextRenderer.width(status);
            TextRenderer.draw(graphics, status, cx - statusW / 2.0f, barY + 14.0f,
                    ColorUtils.withAlpha(theme.getText(), (int) (210 * alpha)), true);

            String percent = Math.round(currentProgress * 100.0f) + "%";
            float percentW = TextRenderer.width(percent);
            TextRenderer.draw(graphics, percent, cx - percentW / 2.0f, barY - 18.0f,
                    ColorUtils.withAlpha(theme.getPrimary(), (int) (230 * alpha)), true);
        }

        if (fadeOutStart != -1L && now - fadeOutStart > FADE_OUT_TIME) {
            minecraft.method_18502(null);
        }
        ci.cancel();
    }

    private String statusText() {
        if (fadeOutStart != -1L) {
            return "Entering world";
        }
        if (reload.method_18787()) {
            return isReadyToFadeOut() ? "Finishing up" : "Building terrain";
        }
        return currentProgress < 0.05f ? "Preparing resources" : "Loading resources";
    }

    private static void drawSpinner(class_332 graphics, float cx, float cy, float radius, long now, float alpha) {
        ThemeManager theme = ThemeManager.get();
        float phase = (now % 1100L) / 1100.0f * ((float) Math.PI * 2.0f);
        int active = 6;
        for (int k = 0; k < active; k++) {
            float segAlpha = (1.0f - k / (float) active) * alpha;
            if (segAlpha <= 0.02f) continue;
            int color = ColorUtils.withAlpha(k == 0 ? theme.getSecondary() : theme.getPrimary(),
                    (int) (255 * segAlpha));
            float a0 = phase - k * 0.42f;
            arc(graphics, cx, cy, radius, a0, a0 + 0.34f, color);
        }
    }

    private static void arc(class_332 graphics, float cx, float cy, float radius, float a0, float a1, int color) {
        int steps = 6;
        float thickness = 2.5f;
        for (int i = 0; i <= steps; i++) {
            float angle = a0 + (a1 - a0) * i / steps;
            float px = cx + (float) Math.cos(angle) * radius - thickness / 2.0f;
            float py = cy + (float) Math.sin(angle) * radius - thickness / 2.0f;
            RenderUtils.fill(graphics, px, py, thickness, thickness, color);
        }
    }
}
