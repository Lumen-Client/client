package dev.lumen.client.mixin;

import dev.lumen.client.modules.visual.CrosshairModule;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Replaces the vanilla crosshair with Lumen's custom crosshair designer.
 */
@Mixin(class_329.class)
public class GuiCrosshairMixin {

    @Inject(method = "renderCrosshair(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V",
            at = @At("HEAD"), cancellable = true)
    private void lumen$customCrosshair(class_332 graphics, class_9779 deltaTracker, CallbackInfo ci) {
        CrosshairModule module = CrosshairModule.get();
        if (module != null && module.isEnabled()) {
            module.renderCrosshair(graphics, graphics.method_51421() / 2, graphics.method_51443() / 2);
            ci.cancel();
        }
    }
}
