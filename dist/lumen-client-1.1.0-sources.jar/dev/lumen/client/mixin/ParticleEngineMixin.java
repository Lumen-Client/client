package dev.lumen.client.mixin;

import dev.lumen.client.modules.perf.ParticleOptimizerModule;
import net.minecraft.class_2394;
import net.minecraft.class_310;
import net.minecraft.class_702;
import net.minecraft.class_703;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Particle cap, distance culling and high-spam particle suppression.
 */
@Mixin(class_702.class)
public class ParticleEngineMixin {

    @Inject(method = "add", at = @At("HEAD"), cancellable = true)
    private void lumen$particleCap(class_703 particle, CallbackInfo ci) {
        ParticleOptimizerModule module = ParticleOptimizerModule.get();
        if (module == null || !module.isEnabled()) return;
        if (!module.canAddParticle()) {
            ci.cancel();
        }
    }

    @Inject(method = "add", at = @At("TAIL"))
    private void lumen$particleAdded(class_703 particle, CallbackInfo ci) {
        ParticleOptimizerModule module = ParticleOptimizerModule.get();
        if (module != null) {
            module.onParticleAdded();
        }
    }

    @Inject(method = "makeParticle", at = @At("HEAD"), cancellable = true)
    private <T extends class_2394> void lumen$distanceCull(T options, double x, double y, double z,
                                                                double xSpeed, double ySpeed, double zSpeed,
                                                                CallbackInfoReturnable<class_703> cir) {
        ParticleOptimizerModule module = ParticleOptimizerModule.get();
        if (module == null || !module.isEnabled()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null) return;
        double distSq = mc.field_1724.method_5649(x, y, z);
        if (distSq > module.getMaxDistanceSq() || module.shouldSuppress(options)) {
            cir.setReturnValue(null);
        }
    }

    @Inject(method = "clearParticles", at = @At("HEAD"))
    private void lumen$cleared(CallbackInfo ci) {
        ParticleOptimizerModule module = ParticleOptimizerModule.get();
        if (module != null) {
            module.resetCount();
        }
    }
}
