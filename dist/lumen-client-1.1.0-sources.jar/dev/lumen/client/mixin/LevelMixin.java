package dev.lumen.client.mixin;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import dev.lumen.client.modules.visual.TimeChangerModule;
import net.minecraft.class_1937;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Client-side sky time override. Only touches ClientLevel instances, so the
 * integrated server's world time is never modified.
 */
@Mixin(class_1937.class)
public class LevelMixin {

    @ModifyReturnValue(method = "getDayTime", at = @At("RETURN"))
    private long lumen$overrideTime(long original) {
        if (!((Object) this instanceof class_638)) return original;
        TimeChangerModule module = TimeChangerModule.get();
        if (module == null) return original;
        return module.getOverriddenTime(original);
    }
}
