package dev.lumen.client.render;

import dev.lumen.client.font.FontManager;
import dev.lumen.client.render.LumenFontRenderer;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Facade that draws with the active Lumen font, falling back to the vanilla
 * font when selected or unavailable.
 */
public final class TextRenderer {
    private TextRenderer() {}

    public static class_327 vanilla() {
        return class_310.method_1551().field_1772;
    }

    public static float width(String text) {
        LumenFontRenderer renderer = FontManager.get().getActiveRenderer();
        float scale = FontManager.get().getFontScale();
        if (renderer != null) {
            return renderer.getWidth(text) * scale;
        }
        return vanilla().method_1727(text) * scale;
    }

    public static float height() {
        LumenFontRenderer renderer = FontManager.get().getActiveRenderer();
        if (renderer != null) {
            return renderer.getCharHeight();
        }
        return vanilla().field_2000;
    }

    public static void draw(class_332 graphics, String text, float x, float y, int argb, boolean shadow) {
        float fontScale = FontManager.get().getFontScale();
        if (fontScale != 1.0f) {
            drawScaled(graphics, text, x, y, argb, fontScale, shadow);
            return;
        }
        LumenFontRenderer renderer = FontManager.get().getActiveRenderer();
        if (renderer != null) {
            FontManager.get().ensureActiveRenderer();
            renderer = FontManager.get().getActiveRenderer();
        }
        if (renderer != null) {
            renderer.drawString(graphics, text, x, y, argb, shadow && FontManager.get().hasShadow());
        } else {
            graphics.method_51433(vanilla(), text, (int) x, (int) y, argb, shadow);
        }
    }

    public static void drawScaled(class_332 graphics, String text, float x, float y, int argb, float scale, boolean shadow) {
        LumenFontRenderer renderer = FontManager.get().getActiveRenderer();
        if (renderer != null) {
            FontManager.get().ensureActiveRenderer();
            renderer = FontManager.get().getActiveRenderer();
        }
        if (renderer != null) {
            renderer.drawScaledString(graphics, text, x, y, argb, scale, shadow && FontManager.get().hasShadow());
        } else {
            graphics.method_51448().pushMatrix();
            graphics.method_51448().translate(x, y);
            graphics.method_51448().scale(scale, scale);
            graphics.method_51433(vanilla(), text, 0, 0, argb, shadow);
            graphics.method_51448().popMatrix();
        }
    }
}
