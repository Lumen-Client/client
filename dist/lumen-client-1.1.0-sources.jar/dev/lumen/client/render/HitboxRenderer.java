package dev.lumen.client.render;

import dev.lumen.client.modules.visual.HitboxesModule;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_12249;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_310;
import net.minecraft.class_4588;

/**
 * Renders themed entity hitbox wireframes during the world render pass via
 * Fabric's AFTER_ENTITIES event, camera-relative and allocation-light.
 */
public final class HitboxRenderer {
    private static boolean registered;

    private HitboxRenderer() {
    }

    public static void register() {
        if (registered) return;
        registered = true;
        WorldRenderEvents.AFTER_ENTITIES.register(HitboxRenderer::afterEntities);
    }

    private static void afterEntities(WorldRenderContext context) {
        HitboxesModule module = HitboxesModule.get();
        if (module == null || !module.isEnabled()) return;
        class_310 mc = class_310.method_1551();
        if (mc.field_1687 == null || mc.field_1724 == null) return;
        class_243 cam = context.gameRenderer().method_19418().method_71156();
        class_4588 lines = context.consumers().method_73477(class_12249.method_76015());
        int argb = module.wireframeColorValue() | 0xFF000000;
        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!module.shouldRenderFor(entity)) continue;
            if (entity == mc.field_1724) continue;
            class_238 box = entity.method_5829().method_989(-cam.field_1352, -cam.field_1351, -cam.field_1350);
            drawBox(lines, box, argb);
        }
    }

    private static void drawBox(class_4588 vc, class_238 box, int argb) {
        float x0 = (float) box.field_1323;
        float y0 = (float) box.field_1322;
        float z0 = (float) box.field_1321;
        float x1 = (float) box.field_1320;
        float y1 = (float) box.field_1325;
        float z1 = (float) box.field_1324;
        line(vc, x0, y0, z0, x1, y0, z0, argb);
        line(vc, x1, y0, z0, x1, y0, z1, argb);
        line(vc, x1, y0, z1, x0, y0, z1, argb);
        line(vc, x0, y0, z1, x0, y0, z0, argb);
        line(vc, x0, y1, z0, x1, y1, z0, argb);
        line(vc, x1, y1, z0, x1, y1, z1, argb);
        line(vc, x1, y1, z1, x0, y1, z1, argb);
        line(vc, x0, y1, z1, x0, y1, z0, argb);
        line(vc, x0, y0, z0, x0, y1, z0, argb);
        line(vc, x1, y0, z0, x1, y1, z0, argb);
        line(vc, x1, y0, z1, x1, y1, z1, argb);
        line(vc, x0, y0, z1, x0, y1, z1, argb);
    }

    private static void line(class_4588 vc, float x0, float y0, float z0, float x1, float y1, float z1, int argb) {
        float nx = x1 - x0;
        float ny = y1 - y0;
        float nz = z1 - z0;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len < 1.0e-4f) return;
        nx /= len;
        ny /= len;
        nz /= len;
        vc.method_22912(x0, y0, z0).method_39415(argb).method_22914(nx, ny, nz);
        vc.method_22912(x1, y1, z1).method_39415(argb).method_22914(nx, ny, nz);
    }
}
