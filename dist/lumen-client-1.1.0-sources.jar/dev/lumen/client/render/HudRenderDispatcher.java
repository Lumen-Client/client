package dev.lumen.client.render;

import dev.lumen.client.LumenClient;
import dev.lumen.client.anim.AnimationUtils;
import dev.lumen.client.core.HudModule;
import dev.lumen.client.render.RenderUtils;
import dev.lumen.client.theme.ColorUtils;
import dev.lumen.client.theme.ThemeManager;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElement;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

/**
 * Dispatches rendering for every enabled HUD module, plus the shared
 * per-frame theme animation update.
 */
public class HudRenderDispatcher implements HudElement {
    public static final class_2960 ID = class_2960.method_60655("lumen", "hud_elements");
    public static final HudRenderDispatcher INSTANCE = new HudRenderDispatcher();

    private long lastNanos;

    @Override
    public void render(class_332 graphics, class_9779 deltaTracker) {
        LumenClient lumen = LumenClient.get();
        if (lumen == null) return;
        lumen.renderTick();

        class_310 minecraft = class_310.method_1551();
        lumen.getModuleManager().get(dev.lumen.client.modules.hud.FpsModule.class).recordFrame();

        if (minecraft.field_1690.field_1842 || minecraft.field_1724 == null) return;
        if (minecraft.field_1755 instanceof dev.lumen.client.gui.HudEditorScreen) return;

        float delta = AnimationUtils.deltaSeconds(lastNanos);
        lastNanos = System.nanoTime();

        ThemeManager theme = lumen.getThemeManager();

        for (HudModule module : lumen.getModuleManager().getHudModules()) {
            if (!module.isEnabled() || !module.shouldShowInEditor()) continue;
            module.preRender();
            boolean empty = module.isContentEmpty();
            graphics.method_51448().pushMatrix();
            graphics.method_51448().translate(module.getX(), module.getY());
            float scale = module.getScale();
            if (scale != 1.0f) {
                graphics.method_51448().scale(scale, scale);
            }
            float opacity = module.getBackgroundOpacity();
            if (opacity > 0.01f && !empty) {
                float width = module.getHudWidth();
                float height = module.getHudHeight();
                int bgColor = ColorUtils.withAlpha(theme.getBackground(), (int) (opacity * 255.0f));
                if (module.hasRoundedCorners()) {
                    RenderUtils.roundedRect(graphics, 0.0f, 0.0f, width, height, 5.0f, bgColor);
                } else {
                    RenderUtils.fill(graphics, 0.0f, 0.0f, width, height, bgColor);
                }
            }
            module.renderHud(graphics, delta);
            graphics.method_51448().popMatrix();
        }
    }
}
