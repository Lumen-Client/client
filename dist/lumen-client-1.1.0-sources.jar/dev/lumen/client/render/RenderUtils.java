package dev.lumen.client.render;

import dev.lumen.client.font.FontManager;
import dev.lumen.client.theme.ColorUtils;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Anti-aliased rounded rectangles, gradients, drop shadows, color wheel and
 * gradient text - all backed by cached dynamic textures so repeated frames
 * never allocate or regenerate pixels.
 */
public final class RenderUtils {
    private static final int SHADOW_TEX = 64;
    private static final int WHEEL_TEX = 128;
    private static final int CORNER_TEX = 64;

    private static final Map<Integer, class_2960> roundedCache = new LinkedHashMap<>(32, 0.75f, false);
    private static final Map<Long, class_2960> gradientCache = new LinkedHashMap<>(64, 0.75f, false);
    private static final Map<Integer, class_2960> wheelCache = new LinkedHashMap<>(4, 0.75f, false);
    private static final Map<Long, class_2960> barCache = new LinkedHashMap<>(4, 0.75f, false);
    private static class_2960 shadowTexture;

    private RenderUtils() {}

    public static void fill(class_332 graphics, float x, float y, float w, float h, int argb) {
        if ((argb >>> 24) == 0) return;
        graphics.method_25294((int) x, (int) y, (int) (x + w), (int) (y + h), argb);
    }

    public static void verticalGradient(class_332 graphics, float x, float y, float w, float h, int from, int to) {
        graphics.method_25296((int) x, (int) y, (int) (x + w), (int) (y + h), from, to);
    }

    public static void border(class_332 graphics, float x, float y, float w, float h, float thickness, int argb) {
        fill(graphics, x, y, w, thickness, argb);
        fill(graphics, x, y + h - thickness, w, thickness, argb);
        fill(graphics, x, y + thickness, thickness, h - thickness * 2.0f, argb);
        fill(graphics, x + w - thickness, y + thickness, thickness, h - thickness * 2.0f, argb);
    }

    private static class_2960 getRoundedTexture(int radius) {
        int r = Math.max(1, Math.min(24, radius));
        class_2960 cached = roundedCache.get(r);
        if (cached != null) return cached;
        cached = generateRoundedTexture(r);
        roundedCache.put(r, cached);
        evictIfNeeded(roundedCache, 32);
        return cached;
    }

    private static class_2960 generateRoundedTexture(int radius) {
        class_1011 image = new class_1011(CORNER_TEX, CORNER_TEX, false);
        float center = (CORNER_TEX - 1) / 2.0f;
        float inner = center - radius;
        for (int y = 0; y < CORNER_TEX; y++) {
            for (int x = 0; x < CORNER_TEX; x++) {
                float coverage = roundedCoverage(x, y, center, center, inner, inner, radius);
                int alpha = (int) (coverage * 255.0f);
                image.method_4305(x, y, (alpha << 24) | 0x00FFFFFF);
            }
        }
        class_2960 id = class_2960.method_60655("lumen", "rounded_" + radius);
        class_310.method_1551().method_1531().method_4616(id, new class_1043(() -> "Lumen Rounded " + radius, image));
        return id;
    }

    /** Signed-distance coverage of a rounded rectangle, 0..1, anti-aliased. */
    private static float roundedCoverage(float x, float y, float centerX, float centerY, float innerX, float innerY, float radius) {
        float qx = Math.abs(x - centerX) - innerX;
        float qy = Math.abs(y - centerY) - innerY;
        float outsideX = Math.max(qx, 0.0f);
        float outsideY = Math.max(qy, 0.0f);
        float outsideDist = (float) Math.sqrt(outsideX * outsideX + outsideY * outsideY);
        float insideDist = Math.min(Math.max(qx, qy), 0.0f);
        float dist = outsideDist + insideDist - radius;
        return Math.max(0.0f, Math.min(1.0f, 0.5f - dist));
    }

    public static void roundedRect(class_332 graphics, float x, float y, float w, float h, float radius, int argb) {
        if (w <= 0 || h <= 0 || (argb >>> 24) == 0) return;
        int r = (int) Math.min(radius, Math.min(w, h) / 2.0f);
        if (r < 1) {
            fill(graphics, x, y, w, h, argb);
            return;
        }
        class_2960 tex = getRoundedTexture(r);
        int corner = Math.min(r + 6, CORNER_TEX / 2);
        if (corner * 2 > w) corner = (int) (w / 2.0f);
        if (corner * 2 > h) corner = (int) (h / 2.0f);
        if (corner < 1) {
            fill(graphics, x, y, w, h, argb);
            return;
        }
        float midW = w - corner * 2.0f;
        float midH = h - corner * 2.0f;

        if (midW > 0 && midH > 0) {
            fill(graphics, x + corner, y + corner, midW, midH, argb);
        }
        if (midW > 0) {
            fill(graphics, x + corner, y, midW, corner, argb);
            fill(graphics, x + corner, y + h - corner, midW, corner, argb);
        }
        if (midH > 0) {
            fill(graphics, x, y + corner, corner, midH, argb);
            fill(graphics, x + w - corner, y + corner, corner, midH, argb);
        }
        drawCorner(graphics, tex, x, y, corner, 0, 0, argb);
        drawCorner(graphics, tex, x + w - corner, y, corner, CORNER_TEX - corner, 0, argb);
        drawCorner(graphics, tex, x, y + h - corner, corner, 0, CORNER_TEX - corner, argb);
        drawCorner(graphics, tex, x + w - corner, y + h - corner, corner, CORNER_TEX - corner, CORNER_TEX - corner, argb);
    }

    private static void drawCorner(class_332 graphics, class_2960 tex, float x, float y, int size, int u, int v, int argb) {
        graphics.method_25291(net.minecraft.class_10799.field_56883, tex, (int) x, (int) y, u, v, size, size, CORNER_TEX, CORNER_TEX, argb);
    }

    public static void roundedGradient(class_332 graphics, float x, float y, float w, float h, float radius, int from, int to, boolean vertical) {
        if (w <= 0 || h <= 0) return;
        long key = (((long) (int) w) << 40) ^ (((long) (int) h) << 24) ^ (((long) (int) radius) << 12)
                ^ (((long) (from & 0xFFFFFF)) << 46) ^ (((long) (to & 0xFFFFFF)) << 22)
                ^ ((long) (from >>> 24) << 8) ^ ((long) (to >>> 24) << 10) ^ (vertical ? 0x2L : 0L);
        class_2960 tex = gradientCache.get(key);
        if (tex == null) {
            tex = generateGradientTexture((int) w, (int) h, (int) radius, from, to, vertical);
            gradientCache.put(key, tex);
            evictIfNeeded(gradientCache, 96);
        }
        graphics.method_25291(net.minecraft.class_10799.field_56883, tex, (int) x, (int) y, 0, 0, (int) w, (int) h, (int) w, (int) h, 0xFFFFFFFF);
    }

    private static class_2960 generateGradientTexture(int w, int h, int radius, int from, int to, boolean vertical) {
        w = Math.max(1, w);
        h = Math.max(1, h);
        class_1011 image = new class_1011(w, h, false);
        float centerX = (w - 1) / 2.0f;
        float centerY = (h - 1) / 2.0f;
        float inner = Math.min(w, h) / 2.0f - radius;
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                float t = vertical ? (h > 1 ? y / (float) (h - 1) : 0.0f) : (w > 1 ? x / (float) (w - 1) : 0.0f);
                int color = ColorUtils.lerp(from, to, t);
                int alpha = ColorUtils.alphaOf(color);
                float innerX = centerX - radius;
                float innerY = centerY - radius;
                float coverage = roundedCoverage(x, y, centerX, centerY, innerX, innerY, radius);
                alpha = (int) (alpha * coverage);
                image.method_4305(x, y, (alpha << 24) | (color & 0xFFFFFF));
            }
        }
        class_2960 id = class_2960.method_60655("lumen", "grad_" + GRAD_COUNTER.incrementAndGet());
        class_310.method_1551().method_1531().method_4616(id, new class_1043(() -> "Lumen Gradient", image));
        return id;
    }

    private static final java.util.concurrent.atomic.AtomicInteger GRAD_COUNTER = new java.util.concurrent.atomic.AtomicInteger();

    public static void dropShadow(class_332 graphics, float x, float y, float w, float h) {
        int soft = 0x38000000;
        roundedRect(graphics, x - 1.5f, y + 2.0f, w + 3.0f, h + 3.0f, 8.0f, soft);
        roundedRect(graphics, x - 3.0f, y + 5.0f, w + 6.0f, h + 4.0f, 10.0f, 0x18000000);
    }

    private static class_2960 generateRadialTexture() {
        class_1011 image = new class_1011(SHADOW_TEX, SHADOW_TEX, false);
        float center = (SHADOW_TEX - 1) / 2.0f;
        for (int y = 0; y < SHADOW_TEX; y++) {
            for (int x = 0; x < SHADOW_TEX; x++) {
                float dx = (x - center) / center;
                float dy = (y - center) / center;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                float alpha = Math.max(0.0f, 1.0f - dist);
                image.method_4305(x, y, ((int) (alpha * 255.0f) << 24) | 0x00FFFFFF);
            }
        }
        class_2960 id = class_2960.method_60655("lumen", "shadow_blob");
        class_310.method_1551().method_1531().method_4616(id, new class_1043(() -> "Lumen Shadow", image));
        return id;
    }

    /** 64px pre-shrunk logo for small UI spots - avoids blurry heavy downscaling. */
    public static final class_2960 LOGO_TEXTURE = class_2960.method_60655("lumen", "logo_small.png");
    /** Full-resolution 512px logo for large renders (loading screen). */
    public static final class_2960 LOGO_TEXTURE_HI = class_2960.method_60655("lumen", "icon.png");

    /**
     * Draws a full registered texture (e.g. the client logo) scaled to w x h.
     */
    public static void drawTexture(class_332 graphics, class_2960 texture, float x, float y, float w, float h, int argb) {
        graphics.method_25291(net.minecraft.class_10799.field_56883, texture,
                (int) x, (int) y, 0.0f, 0.0f, (int) w, (int) h, (int) w, (int) h, argb);
    }

    public static void colorWheel(class_332 graphics, float x, float y, float size) {
        int s = (int) size;
        if (s < 2) return;
        class_2960 tex = wheelCache.get(s);
        if (tex == null) {
            tex = generateWheelTexture(s);
            wheelCache.put(s, tex);
            evictIfNeeded(wheelCache, 8);
        }
        graphics.method_25291(net.minecraft.class_10799.field_56883, tex,
                (int) x, (int) y, 0.0f, 0.0f, s, s, s, s, 0xFFFFFFFF);
    }

    private static class_2960 generateWheelTexture(int size) {
        class_1011 image = new class_1011(size, size, false);
        float center = (size - 1) / 2.0f;
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                float dx = (x - center) / center;
                float dy = (y - center) / center;
                float dist = (float) Math.sqrt(dx * dx + dy * dy);
                if (dist > 1.0f) {
                    image.method_4305(x, y, 0);
                    continue;
                }
                float hue = (float) (Math.atan2(dy, dx) / (Math.PI * 2.0));
                if (hue < 0.0f) hue += 1.0f;
                float sat = Math.min(1.0f, dist);
                int rgb = java.awt.Color.HSBtoRGB(hue, sat, 1.0f) & 0xFFFFFF;
                image.method_4305(x, y, (dist < 0.985f ? 0xFF000000 : 0xC0000000) | rgb);
            }
        }
        class_2960 id = class_2960.method_60655("lumen", "color_wheel_" + size);
        class_310.method_1551().method_1531().method_4616(id, new class_1043(() -> "Lumen Color Wheel", image));
        return id;
    }

    public static void brightnessBar(class_332 graphics, float x, float y, float w, float h) {
        int bw = (int) w;
        int bh = (int) h;
        if (bw < 1 || bh < 1) return;
        long key = ((long) bw << 16) | bh;
        class_2960 tex = barCache.get(key);
        if (tex == null) {
            tex = generateBarTexture(bw, bh);
            barCache.put(key, tex);
            evictIfNeeded(barCache, 8);
        }
        graphics.method_25291(net.minecraft.class_10799.field_56883, tex,
                (int) x, (int) y, 0.0f, 0.0f, bw, bh, bw, bh, 0xFFFFFFFF);
    }

    private static class_2960 generateBarTexture(int w, int h) {
        class_1011 image = new class_1011(w, h, false);
        for (int x = 0; x < w; x++) {
            int color = java.awt.Color.HSBtoRGB(0.0f, 0.0f, x / (float) (w - 1)) & 0xFFFFFF;
            for (int y = 0; y < h; y++) {
                image.method_4305(x, y, 0xFF000000 | color);
            }
        }
        class_2960 id = class_2960.method_60655("lumen", "brightness_bar_" + w + "x" + h);
        class_310.method_1551().method_1531().method_4616(id, new class_1043(() -> "Lumen Brightness Bar", image));
        return id;
    }

    public static void drawGradientText(class_332 graphics, class_327 font, String text, float x, float y, int from, int to, boolean shadow, float phase) {
        int length = text.length();
        int charX = (int) x;
        for (int i = 0; i < length; i++) {
            String ch = String.valueOf(text.charAt(i));
            float t = (i / (float) Math.max(1, length - 1)) * 0.6f + phase;
            t -= Math.floor(t);
            int color = ColorUtils.lerp(from, to, t);
            if (shadow) {
                graphics.method_51433(font, ch, charX + 1, (int) y + 1, ColorUtils.withAlpha(0xFF000000, ColorUtils.alphaOf(color)), false);
            }
            graphics.method_51433(font, ch, charX, (int) y, color, false);
            charX += font.method_1727(ch);
        }
    }

    public static void drawGradientTextCustom(class_332 graphics, String text, float x, float y, int from, int to, boolean shadow, float phase) {
        LumenFontRenderer renderer = FontManager.get().getActiveRenderer();
        if (renderer == null) {
            drawGradientText(graphics, class_310.method_1551().field_1772, text, x, y, from, to, shadow, phase);
            return;
        }
        int length = text.length();
        float charX = x;
        for (int i = 0; i < length; i++) {
            float t = (i / (float) Math.max(1, length - 1)) * 0.6f + phase;
            t -= Math.floor(t);
            int color = ColorUtils.lerp(from, to, t);
            String ch = String.valueOf(text.charAt(i));
            renderer.drawString(graphics, ch, charX, y, color, shadow);
            charX += renderer.getWidth(ch);
        }
    }

    private static void evictIfNeeded(Map<?, ?> cache, int max) {
        Iterator<?> it = cache.keySet().iterator();
        while (cache.size() > max && it.hasNext()) {
            it.next();
            it.remove();
        }
    }

    public static void clearCaches() {
        roundedCache.clear();
        gradientCache.clear();
        wheelCache.clear();
        barCache.clear();
    }
}
