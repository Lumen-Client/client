package dev.lumen.client.gui.components;

import dev.lumen.client.render.RenderUtils;
import dev.lumen.client.theme.ColorUtils;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import net.minecraft.class_11905;
import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;

/**
 * HSB color picker: interactive color wheel, brightness bar, live preview
 * and hex input. State is cached - no per-frame allocation.
 */
public class ColorPickerPanel {
    public static final float WIDTH = 156.0f;
    public static final float HEIGHT = 178.0f;

    private boolean open;
    private float x;
    private float y;

    private IntSupplier getter;
    private IntConsumer setter;

    private float hue;
    private float sat = 1.0f;
    private float bri = 1.0f;

    private class_342 hexBox;
    private boolean draggingWheel;
    private boolean draggingBrightness;
    private boolean updatingHex;

    public boolean isOpen() {
        return open;
    }

    public void close() {
        open = false;
        draggingWheel = false;
        draggingBrightness = false;
    }

    public float getX() {
        return x;
    }

    public float getY() {
        return y;
    }

    public void open(IntSupplier getter, IntConsumer setter, float x, float y) {
        this.getter = getter;
        this.setter = setter;
        this.x = Math.min(x, class_310.method_1551().method_22683().method_4486() - WIDTH - 8.0f);
        this.y = Math.min(y, class_310.method_1551().method_22683().method_4502() - HEIGHT - 8.0f);
        int argb = getter.getAsInt();
        float[] hsb = ColorUtils.rgbToHsb(argb);
        hue = hsb[0];
        sat = hsb[1];
        bri = hsb[2];
        ensureHexBox();
        updatingHex = true;
        hexBox.method_1852(ColorUtils.toHex(argb));
        updatingHex = false;
        open = true;
    }

    private void ensureHexBox() {
        if (hexBox == null) {
            hexBox = new class_342(class_310.method_1551().field_1772, 0, 0, 64, 14, class_2561.method_43470("#RRGGBB"));
            hexBox.method_1880(7);
            hexBox.method_1890(s -> s.isEmpty() || s.matches("^#?[0-9a-fA-F]{1,6}"));
            hexBox.method_1863(s -> {
                if (!updatingHex) {
                    int parsed = ColorUtils.parseHex(s);
                    if (parsed != -1) {
                        applyColor(parsed);
                    }
                }
            });
        }
    }

    private void applyColor(int argb) {
        if (setter != null) {
            setter.accept(argb | 0xFF000000);
        }
    }

    private int currentColor() {
        return ColorUtils.hsbToRgb(hue, sat, bri, 255);
    }

    private void commitCurrent() {
        applyColor(currentColor());
    }

    public void render(class_332 graphics, int mouseX, int mouseY, float delta, float alpha) {
        if (!open) return;
        RenderUtils.dropShadow(graphics, x, y, WIDTH, HEIGHT);
        RenderUtils.roundedRect(graphics, x, y, WIDTH, HEIGHT, 8.0f, ColorUtils.withAlpha(0xFF14141A, (int) (255 * alpha)));

        float wheelSize = 96.0f;
        float wheelX = x + 8.0f;
        float wheelY = y + 20.0f;
        RenderUtils.colorWheel(graphics, wheelX, wheelY, wheelSize);

        float cx = wheelX + wheelSize / 2.0f;
        float cy = wheelY + wheelSize / 2.0f;
        float markerDist = sat * (wheelSize / 2.0f - 2.0f);
        double angle = hue * Math.PI * 2.0;
        float markerX = cx + (float) Math.cos(angle) * markerDist;
        float markerY = cy + (float) Math.sin(angle) * markerDist;
        RenderUtils.roundedRect(graphics, markerX - 2.5f, markerY - 2.5f, 5.0f, 5.0f, 2.5f, 0xFFFFFFFF);

        float barY = wheelY + wheelSize + 6.0f;
        RenderUtils.brightnessBar(graphics, wheelX, barY, wheelSize, 10.0f);
        float briX = wheelX + wheelSize * bri;
        RenderUtils.roundedRect(graphics, briX - 2.0f, barY - 2.0f, 4.0f, 14.0f, 2.0f, 0xFFFFFFFF);

        RenderUtils.roundedRect(graphics, x + 8.0f, y + HEIGHT - 26.0f, 16.0f, 16.0f, 4.0f, currentColor() | 0xFF000000);

        hexBox.method_46421((int) (x + 30.0f));
        hexBox.method_46419((int) (y + HEIGHT - 24.0f));
        hexBox.method_25358(64);
        hexBox.method_25394(graphics, mouseX, mouseY, delta);
    }

    public boolean mouseClicked(class_11909 event, boolean doubled) {
        if (!open) return false;
        double mx = event.comp_4798();
        double my = event.comp_4799();

        float wheelSize = 96.0f;
        float wheelX = x + 8.0f;
        float wheelY = y + 20.0f;
        float cx = wheelX + wheelSize / 2.0f;
        float cy = wheelY + wheelSize / 2.0f;
        float dx = (float) (mx - cx);
        float dy = (float) (my - cy);
        float dist = (float) Math.sqrt(dx * dx + dy * dy);
        if (dist <= wheelSize / 2.0f + 2.0f) {
            draggingWheel = true;
            updateWheel(dx, dy, dist, wheelSize);
            return true;
        }

        float barY = wheelY + wheelSize + 6.0f;
        if (mx >= wheelX && mx <= wheelX + wheelSize && my >= barY - 3 && my <= barY + 13) {
            draggingBrightness = true;
            bri = Math.max(0.0f, Math.min(1.0f, (float) ((mx - wheelX) / wheelSize)));
            commitCurrent();
            return true;
        }

        if (hexBox.method_25405(mx, my)) {
            hexBox.method_25365(true);
            hexBox.method_25402(event, doubled);
            return true;
        }
        hexBox.method_25365(false);

        if (mx >= x && mx <= x + WIDTH && my >= y && my <= y + HEIGHT) {
            return true;
        }
        close();
        return false;
    }

    public boolean mouseDragged(class_11909 event, double dragX, double dragY) {
        if (!open) return false;
        float wheelSize = 96.0f;
        float wheelX = x + 8.0f;
        float wheelY = y + 20.0f;
        float cx = wheelX + wheelSize / 2.0f;
        float cy = wheelY + wheelSize / 2.0f;
        float dx = (float) (event.comp_4798() - cx);
        float dy = (float) (event.comp_4799() - cy);
        if (draggingWheel) {
            updateWheel(dx, dy, (float) Math.sqrt(dx * dx + dy * dy), wheelSize);
            return true;
        }
        if (draggingBrightness) {
            bri = Math.max(0.0f, Math.min(1.0f, (float) ((event.comp_4798() - wheelX) / wheelSize)));
            commitCurrent();
            return true;
        }
        return false;
    }

    public boolean mouseReleased() {
        boolean was = draggingWheel || draggingBrightness;
        draggingWheel = false;
        draggingBrightness = false;
        return was;
    }

    private void updateWheel(float dx, float dy, float dist, float wheelSize) {
        double angle = Math.atan2(dy, dx);
        if (angle < 0) angle += Math.PI * 2.0;
        hue = (float) (angle / (Math.PI * 2.0));
        sat = Math.min(1.0f, dist / (wheelSize / 2.0f - 2.0f));
        commitCurrent();
    }

    public boolean keyPressed(class_11908 event) {
        if (!open) return false;
        if (event.comp_4795() == 256) {
            close();
            return true;
        }
        return hexBox.method_25370() && hexBox.method_25404(event);
    }

    public boolean charTyped(class_11905 event) {
        if (!open) return false;
        return hexBox.method_25400(event);
    }
}
